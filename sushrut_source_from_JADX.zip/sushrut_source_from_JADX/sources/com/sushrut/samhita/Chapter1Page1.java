package com.sushrut.samhita;

import android.graphics.Typeface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class Chapter1Page1 extends Fragment {
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(C0134R.layout.chapter1page1, container, false);
        ((TextView) view.findViewById(C0134R.id.chapter1text1)).setTypeface(Typeface.createFromAsset(getActivity().getAssets(), "fonts/mangal.ttf"));
        return view;
    }
}
