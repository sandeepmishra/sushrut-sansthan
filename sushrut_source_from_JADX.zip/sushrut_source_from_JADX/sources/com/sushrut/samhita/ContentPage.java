package com.sushrut.samhita;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ContentPage extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0134R.layout.content_page);
    }

    public void onContinue(View view) {
        startActivity(new Intent(this, ChaptersList.class));
    }
}
