package com.sushrut.samhita;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends FragmentActivity {
    int[] chapterCount;
    List<Fragment> chapterFragments;
    ChapterList chapterList;
    int chaptercount;
    private MyAdapter mAdapter;
    private ViewPager mPager;

    class ChapterList {
        ChapterList() {
        }

        public void addChapter(int pos) {
            MainActivity.this.chapterFragments.addAll(getChapter(pos));
        }

        public List<Fragment> getChapter(int pos) {
            List<Fragment> list = new ArrayList();
            switch (pos) {
                case 0:
                    list.add(new Chapter1Page1());
                    list.add(new Chapter1Page2());
                    list.add(new Chapter1Page3());
                    list.add(new Chapter1Page4());
                    return list;
                case 1:
                    list.add(new Chapter2Page1());
                    list.add(new Chapter2Page2());
                    return list;
                case 2:
                    list.add(new Chapter3Page1());
                    list.add(new Chapter3Page2());
                    return list;
                case 3:
                    list.add(new Chapter4Page1());
                    list.add(new Chapter4Page2());
                    return list;
                case 4:
                    list.add(new Chapter5Page1());
                    list.add(new Chapter5Page2());
                    list.add(new Chapter5Page3());
                    return list;
                case 5:
                    list.add(new Chapter6Page1());
                    list.add(new Chapter6Page2());
                    return list;
                case 6:
                    list.add(new Chapter7Page1());
                    list.add(new Chapter7Page2());
                    return list;
                case 7:
                    list.add(new Chapter8Page1());
                    list.add(new Chapter8Page2());
                    return list;
                case 8:
                    list.add(new Chapter9Page1());
                    list.add(new Chapter9Page2());
                    return list;
                case 9:
                    list.add(new Chapter10Page1());
                    list.add(new Chapter10Page2());
                    return list;
                case 10:
                    list.add(new Chapter11Page1());
                    list.add(new Chapter11Page2());
                    return list;
                case 11:
                    list.add(new Chapter12Page1());
                    list.add(new Chapter12Page2());
                    return list;
                case 12:
                    list.add(new Chapter13Page1());
                    list.add(new Chapter13Page2());
                    list.add(new Chapter13Page3());
                    return list;
                case 13:
                    list.add(new Chapter14Page1());
                    return list;
                case 14:
                    list.add(new Chapter15Page1());
                    return list;
                case 15:
                    list.add(new Chapter16Page1());
                    list.add(new Chapter16Page2());
                    list.add(new Chapter16Page3());
                    return list;
                default:
                    return null;
            }
        }
    }

    public class MyAdapter extends FragmentPagerAdapter {
        public MyAdapter(FragmentManager fm) {
            super(fm);
        }

        public int getCount() {
            return 36;
        }

        public Fragment getItem(int position) {
            switch (position) {
                case 0:
                    return new Chapter1Page1();
                case 1:
                    return new Chapter1Page2();
                case 2:
                    return new Chapter1Page3();
                case 3:
                    return new Chapter1Page4();
                case 4:
                    return new Chapter2Page1();
                case 5:
                    return new Chapter2Page2();
                case 6:
                    return new Chapter3Page1();
                case 7:
                    return new Chapter3Page2();
                case 8:
                    return new Chapter4Page1();
                case 9:
                    return new Chapter4Page2();
                case 10:
                    return new Chapter5Page1();
                case 11:
                    return new Chapter5Page2();
                case 12:
                    return new Chapter5Page3();
                case 13:
                    return new Chapter6Page1();
                case 14:
                    return new Chapter6Page2();
                case 15:
                    return new Chapter7Page1();
                case 16:
                    return new Chapter7Page2();
                case 17:
                    return new Chapter8Page1();
                case 18:
                    return new Chapter8Page2();
                case 19:
                    return new Chapter9Page1();
                case 20:
                    return new Chapter9Page2();
                case 21:
                    return new Chapter10Page1();
                case 22:
                    return new Chapter10Page2();
                case 23:
                    return new Chapter11Page1();
                case 24:
                    return new Chapter11Page2();
                case 25:
                    return new Chapter12Page1();
                case 26:
                    return new Chapter12Page2();
                case 27:
                    return new Chapter13Page1();
                case 28:
                    return new Chapter13Page2();
                case 29:
                    return new Chapter13Page3();
                case 30:
                    return new Chapter14Page1();
                case 31:
                    return new Chapter15Page1();
                case 32:
                    return new Chapter16Page1();
                case 33:
                    return new Chapter16Page2();
                case 34:
                    return new Chapter16Page3();
                case 35:
                    return new Chapter16Page4();
                default:
                    return null;
            }
        }
    }

    public MainActivity() {
        int[] iArr = new int[16];
        iArr[1] = 4;
        iArr[2] = 6;
        iArr[3] = 8;
        iArr[4] = 10;
        iArr[5] = 13;
        iArr[6] = 15;
        iArr[7] = 17;
        iArr[8] = 19;
        iArr[9] = 21;
        iArr[10] = 23;
        iArr[11] = 25;
        iArr[12] = 27;
        iArr[13] = 30;
        iArr[14] = 31;
        iArr[15] = 32;
        this.chapterCount = iArr;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(C0134R.layout.activity_main);
        this.chaptercount = getIntent().getIntExtra("selChapter", 0);
        this.mAdapter = new MyAdapter(getSupportFragmentManager());
        this.chapterFragments = new ArrayList();
        this.mPager = (ViewPager) findViewById(C0134R.id.pager);
        this.mPager.setAdapter(this.mAdapter);
        this.mPager.setCurrentItem(this.chapterCount[this.chaptercount]);
    }
}
