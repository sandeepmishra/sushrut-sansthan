package com.sushrut.samhita;

public final class BuildConfig {
    public static final boolean DEBUG = false;
}
